# MemoryMatchingGame
This game was developed in C# 

## YouTube Video
This is the development tutorial URL
https://youtu.be/6i5t_QYa4m4

## Contribution
Contribution to this game is allowed; however, Please include your name and description of what you have done on top of the source file you have developed or updated.

This is necessary so I can credit you 

Additionally, please any development take them to the DEVELOPMENT branch

## License
This project is under MIT license, you are free to do whatever you like with this project including commercial use as long as you provide attribution back to the author as well as including the [LICENSE.md](LICENSE.md) file in this repository within your project.

Please see [LICENSE.md](LICENSE.md) file for details for more details